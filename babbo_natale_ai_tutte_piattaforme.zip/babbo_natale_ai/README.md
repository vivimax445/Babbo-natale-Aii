# Babbo Natale AI

Demo web di conversazione vocale in tempo reale con un avatar natalizio illustrato.

## Requisiti
- Node.js 18 o superiore
- Un progetto OpenAI Platform con API access e fatturazione/configurazione API attiva
- Browser moderno con microfono, su HTTPS in produzione (localhost va bene in sviluppo)

## Avvio
1. Estrai lo ZIP.
2. Copia `.env.example` in `.env`.
3. Inserisci la tua chiave API in `OPENAI_API_KEY` dentro `.env`. Non inserirla mai in `public/index.html` e non condividerla.
4. Nel terminale, nella cartella del progetto, esegui:
   ```bash
   npm install
   npm start
   ```
5. Apri http://localhost:3000 e premi **INIZIA LA CHIAMATA**.
6. Consenti l'accesso al microfono.

## Note
- Il server genera un client secret temporaneo per ogni chiamata; la chiave API principale non viene inviata al browser.
- Le chiamate Realtime possono comportare costi API in base all'utilizzo e al modello. Controlla i limiti di spesa del progetto.
- L'avatar attuale è un'illustrazione CSS animata, non un video realistico con sincronizzazione labiale.
- Prima di pubblicare online, usa HTTPS, aggiungi limiti di frequenza e protezione anti-abuso all'endpoint `/api/session`, e configura un budget/limite di spesa.


## Installazione come app su telefono e computer (PWA)
Il progetto include manifest, icona e service worker. Dopo averlo pubblicato su un dominio HTTPS:
- Android/Chrome: apri il sito e scegli "Installa app" oppure "Aggiungi a schermata Home".
- iPhone/iPad: apri il sito in Safari, tocca Condividi e poi "Aggiungi alla schermata Home".
- Desktop compatibili: usa l'icona Installa nella barra degli indirizzi oppure il pulsante "Installa app" quando compare.

La conversazione vocale richiede una connessione Internet e l'accesso al microfono. La sola interfaccia può essere memorizzata per l'apertura offline, ma la chiamata AI non funziona senza rete.

## Pubblicazione negli store
Questa consegna è una PWA installabile da browser. La pubblicazione su Google Play e Apple App Store richiede ulteriori passaggi di confezionamento, account sviluppatore, firme e revisione degli store; non è automatica né inclusa in questo ZIP.
