import "dotenv/config";
import express from "express";

const app = express();
app.use(express.static("public"));

app.get("/api/session", async (_req, res) => {
  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({ error: "Configura OPENAI_API_KEY nel file .env sul server." });
  }

  try {
    const response = await fetch("https://api.openai.com/v1/realtime/client_secrets", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        expires_after: { anchor: "created_at", seconds: 600 },
        session: {
          type: "realtime",
          model: "gpt-realtime-2.1",
          instructions: `Sei Babbo Natale, un personaggio natalizio gentile, allegro e rassicurante.
Parli sempre in italiano, a meno che l'utente chieda un'altra lingua.
Rispondi in modo naturale, caloroso, semplice e adatto a famiglie e ragazzi.
Puoi parlare del Natale, delle tradizioni, delle renne, degli elfi, dei regali e rispondere a domande generali.
Non sostenere di poter vedere l'utente o conoscere informazioni private. Non promettere regali reali.
Se non conosci una risposta, dillo con sincerità. Mantieni le risposte concise e fai una domanda di seguito quando è utile.`,
          audio: {
            input: { turn_detection: { type: "server_vad" } },
            output: { voice: "marin" }
          }
        }
      })
    });

    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "Errore OpenAI" });
    res.json({ value: data.value });
  } catch {
    res.status(500).json({ error: "Impossibile creare la sessione Realtime." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Babbo Natale AI disponibile su http://localhost:${port}`));